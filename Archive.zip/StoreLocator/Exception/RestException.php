<?php
namespace Highgrove\StoreLocator\Exception;

/**
 * Class RestException
 */
class RestException extends \Exception
{

}
